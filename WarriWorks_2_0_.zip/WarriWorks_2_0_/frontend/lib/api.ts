const API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000/api';
export type Artisan={id:number;display_name:string;skill:string;location:string;bio:string;verified:boolean;profile_image:string|null;years_experience:number;is_available:boolean};
export type Paginated<T>={count:number;next:string|null;previous:string|null;results:T[]};
function cookie(name:string){if(typeof document==='undefined')return '';return document.cookie.split('; ').find(x=>x.startsWith(`${name}=`))?.split('=').slice(1).join('=')??'';}
export async function api<T>(path:string,options:RequestInit={}):Promise<T>{
 const method=(options.method??'GET').toUpperCase();
 const headers=new Headers(options.headers); if(!(options.body instanceof FormData))headers.set('Content-Type','application/json');
 if(!['GET','HEAD','OPTIONS','TRACE'].includes(method)){const csrf=cookie('csrftoken');if(csrf)headers.set('X-CSRFToken',decodeURIComponent(csrf));}
 const res=await fetch(`${API}${path}`,{...options,headers,credentials:'include',cache:'no-store'});
 if(!res.ok){let message=`Request failed (${res.status})`;try{const body=await res.json();message=body.detail??JSON.stringify(body)}catch{}throw new Error(message)}
 if(res.status===204)return undefined as T;return res.json();
}
